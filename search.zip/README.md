# Search dokumen dengan Flask
implementasi search engine dengan framework Flask menggunakan  **Python 2.7**

### Installasi requirement
```
pip install -r requirements.txt
```

### Running
```
python run.py
```

### Acknowledgments
* https://github.com/rianrajagede/flask-search.git# Articles-search-engine
